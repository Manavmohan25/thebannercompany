// Products data will be loaded from CSV
let productsData = [];

// Initialize the page
document.addEventListener('DOMContentLoaded', function() {
    loadProductsFromCSV();
    setupEventListeners();
    setupFAQ();
});

// Load products from CSV file
function loadProductsFromCSV() {
    fetch('products.csv')
        .then(response => response.text())
        .then(csvData => {
            productsData = parseCSV(csvData);
            loadProducts();
        })
        .catch(error => {
            console.error('Error loading products:', error);
            // Load default products if CSV fails
            loadDefaultProducts();
        });
}

// Parse CSV data
function parseCSV(csvText) {
    const lines = csvText.trim().split('\n');
    const headers = lines[0].split(',').map(h => h.trim());
    const products = [];
    
    for (let i = 1; i < lines.length; i++) {
        if (lines[i].trim() === '') continue;
        
        // Handle quoted fields properly
        const values = parseCSVLine(lines[i]);
        const product = {};
        
        headers.forEach((header, index) => {
            let value = values[index] ? values[index].trim() : '';
            
            // Handle different data types
            if (header === 'price') {
                value = parseFloat(value);
            } else if (header === 'reviews') {
                value = parseInt(value) || 0;
            } else if (header === 'rating') {
                value = parseFloat(value) || 0;
            }
            
            product[header] = value;
        });
        
        products.push(product);
    }
    
    return products;
}

// Parse CSV line handling quoted fields
function parseCSVLine(line) {
    const values = [];
    let current = '';
    let inQuotes = false;
    
    for (let i = 0; i < line.length; i++) {
        const char = line[i];
        
        if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
            values.push(current);
            current = '';
        } else {
            current += char;
        }
    }
    values.push(current);
    
    return values.map(v => v.replace(/^"|"$/g, '').trim());
}

// Load default products if CSV fails
function loadDefaultProducts() {
    productsData = [
        {
            name: "Balloons",
            category: "Balloons",
            description: "Colorful balloons for every occasion",
            price: 299,
            rating: 4,
            reviews: 120,
            amazon_link: "https://www.amazon.in/s?k=party+balloons"
        },
        {
            name: "Banners",
            category: "Banners",
            description: "Stunning banners and garlands",
            price: 399,
            rating: 5,
            reviews: 95,
            amazon_link: "https://www.amazon.in/s?k=party+banners"
        },
        {
            name: "Party Kits",
            category: "Combos",
            description: "Complete solutions for your celebrations",
            price: 599,
            rating: 4,
            reviews: 88,
            amazon_link: "https://www.amazon.in/s?k=party+kits"
        },
        {
            name: "Props",
            category: "Props",
            description: "Fun photo booth props and accessories",
            price: 349,
            rating: 4,
            reviews: 74,
            amazon_link: "https://www.amazon.in/s?k=photo+booth+props"
        },
        {
            name: "Cupcake Toppers",
            category: "Cupcake Toppers",
            description: "Decorative cupcake toppers for any event",
            price: 199,
            rating: 5,
            reviews: 143,
            amazon_link: "https://www.amazon.in/s?k=cupcake+toppers"
        },
        {
            name: "Cake Toppers",
            category: "Cake Toppers",
            description: "Beautiful cake toppers for celebrations",
            price: 249,
            rating: 4,
            reviews: 88,
            amazon_link: "https://www.amazon.in/s?k=cake+toppers"
        }
    ];
    loadProducts();
}

// Load and display products
function loadProducts() {
    const productsGrid = document.getElementById('productsGrid');
    const homeProductsGrid = document.getElementById('homeProductsGrid');
    
    if (productsGrid) {
        productsGrid.innerHTML = '';
        productsData.forEach(product => {
            const productCard = createProductCard(product);
            productsGrid.appendChild(productCard);
        });
    }
    
    if (homeProductsGrid) {
        homeProductsGrid.innerHTML = '';
        // Show only first 4 products on home page
        const homeProducts = productsData.slice(0, 4);
        homeProducts.forEach(product => {
            const productCard = createProductCard(product);
            homeProductsGrid.appendChild(productCard);
        });
    }
}

// Create product card HTML
function createProductCard(product) {
    const card = document.createElement('div');
    card.className = 'product-card';
    
    // Generate star rating
    const rating = product.rating || 0;
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5 ? 1 : 0;
    const emptyStars = 5 - fullStars - halfStar;
    
    let stars = '★'.repeat(fullStars);
    if (halfStar) stars += '⯨';
    stars += '☆'.repeat(emptyStars);
    
    // Format price in INR
    const priceFormatted = new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        maximumFractionDigits: 0
    }).format(product.price || 0);
    
    // Get image path or use placeholder
    const imagePath = product.image || 'assets/placeholder-product.jpg';
    
    // Get Amazon link
    const amazonLink = product.amazon_link || 'https://www.amazon.in/s?k=party+supplies';
    
    card.innerHTML = `
        <img src="${imagePath}" alt="${product.name}" class="product-image" onerror="this.src='assets/placeholder-product.jpg'">
        <div class="product-info">
            <h3 class="product-title">${product.name}</h3>
            <div class="product-rating">${stars} (${product.reviews || 0})</div>
            <p class="product-description">${product.description || ''}</p>
            <div class="product-price">
                <span class="current-price">${priceFormatted}</span>
            </div>
            <a href="${amazonLink}" target="_blank" class="product-button">Shop on Amazon</a>
        </div>
    `;
    
    return card;
}

// Setup event listeners
function setupEventListeners() {
    // Contact form submission
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(contactForm);
            const formMessage = document.getElementById('formMessage');
            
            // Show loading state
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.textContent;
            submitBtn.textContent = 'Sending...';
            submitBtn.disabled = true;
            
            fetch('send_email.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                
                if (data.success) {
                    formMessage.className = 'form-message success';
                    formMessage.textContent = data.message;
                    contactForm.reset();
                } else {
                    formMessage.className = 'form-message error';
                    formMessage.textContent = data.message;
                }
                
                // Hide message after 5 seconds
                setTimeout(() => {
                    formMessage.className = 'form-message';
                }, 5000);
            })
            .catch(error => {
                submitBtn.textContent = originalText;
                submitBtn.disabled = false;
                formMessage.className = 'form-message error';
                formMessage.textContent = 'An error occurred. Please try again.';
                console.error('Error:', error);
            });
        });
    }
}

// Setup FAQ accordion
function setupFAQ() {
    const faqQuestions = document.querySelectorAll('.faq-question');
    
    faqQuestions.forEach(question => {
        question.addEventListener('click', function() {
            const faqItem = this.parentElement;
            const isActive = faqItem.classList.contains('active');
            
            // Close all FAQ items
            document.querySelectorAll('.faq-item').forEach(item => {
                item.classList.remove('active');
            });
            
            // Open clicked item if it wasn't active
            if (!isActive) {
                faqItem.classList.add('active');
            }
        });
    });
}